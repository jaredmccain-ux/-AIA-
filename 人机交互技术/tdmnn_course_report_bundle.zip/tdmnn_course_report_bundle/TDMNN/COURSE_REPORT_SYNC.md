# 课程报告（任务2）— 二分类指标图 + 打包同步到本地

## 1. 二分类：导出每折预测（用于 P/R/F1、混淆矩阵）

### 方式 A：已有训好的 checkpoint（只推理，不重训）

需目录结构为：`{model_dir}/subject_XX/fold_K/best_model{1,2,3}.keras`（或 `.h5`）。与 `start_deap_binary_tmux.sh` 一致时一般为：

- `TDMNN/models_binary_valence`
- `TDMNN/models_binary_arousal`

```bash
cd /root/inpainting-work
export TF_USE_LEGACY_KERAS=1

python interactive/TDMNN/infer_deap_binary_from_checkpoints.py \
  --flag v \
  --model-dir interactive/TDMNN/models_binary_valence \
  --artifacts-dir interactive/TDMNN/artifacts_binary_v \
  --out-json interactive/TDMNN/deap_valence_infer_summary.json

python interactive/TDMNN/infer_deap_binary_from_checkpoints.py \
  --flag a \
  --model-dir interactive/TDMNN/models_binary_arousal \
  --artifacts-dir interactive/TDMNN/artifacts_binary_a \
  --out-json interactive/TDMNN/deap_arousal_infer_summary.json
```

划分与训练脚本相同：`StratifiedKFold(5, shuffle=True, random_state=7)`。

### 方式 B：没有 checkpoint、愿意重新训练

在服务器上（需已有 `TDMNN/deap_mat/DE_s*.mat`），加 `--artifacts-dir` 跑 `run_deap_original_style.py`（与仓库内脚本一致）。

### 生成二分类可视化（在已有 `artifacts_binary_*` 的 npz 之后）

```bash
python interactive/TDMNN/plot_deap_binary_metrics.py \
  --artifacts-dir interactive/TDMNN/artifacts_binary_v \
  --flag v \
  --out-dir interactive/TDMNN/figures_binary

python interactive/TDMNN/plot_deap_binary_metrics.py \
  --artifacts-dir interactive/TDMNN/artifacts_binary_a \
  --flag a \
  --out-dir interactive/TDMNN/figures_binary
```

输出包括：

- `figures_binary/binary_valence_confusion_matrix.png`（或 `binary_arousal_...`）
- `figures_binary/binary_*_metrics_bars.png`
- `figures_binary/binary_metrics_from_preds_valence.json` / `binary_metrics_from_preds_arousal.json`（按任务分别命名，同一 `--out-dir` 也可）

## 2. 三分类：从已有 `tables/` 生成图（无需模型）

需已存在 `tables/valence_3class_confusion_matrix.json` 与 `tables/metrics_summary.json`（由 `tabulate_metrics.py` 生成过）：

```bash
python interactive/TDMNN/visualize_threeclass_report_figures.py
```

输出在 `TDMNN/figures_threeclass/`。

## 3. 打包传到 Windows `E:\interactive`

在服务器打包：

```bash
bash /root/inpainting-work/interactive/package_tdmnn_course_report.sh
```

在 **Windows** 上（将 `<SERVER>` 换成主机名或 IP；将 `root` 换成你的 SSH 用户）：

```powershell
scp root@<SERVER>:/root/inpainting-work/interactive/tdmnn_course_report_bundle.tar.gz E:\interactive\
```

解压（**Git Bash** 或 Windows 自带 `tar`）：

```bash
cd /e/interactive
tar xzvf tdmnn_course_report_bundle.tar.gz
```

解压后会出现 `TDMNN/`、`人机交互选修课大作业.pdf` 等目录与文件。

## 4. 不包含的内容

打包脚本**故意不包含**：`models_*`、`*.keras` / `.h5`、大体积 `deap_mat/`、原始 `s*.dat`、`TDMNN/.git/`、`artifacts_binary_*`（`preds_*.npz`）、`logs/`、`run_deap_proper_eval.py`（方案 A/B）、`deap_B_loso_*`、`smoke_*` 等。

打包**会包含**：`TDMNN-all/`、论文式二分类/三分类主脚本、各类 `deap_*.json`、`tables/`、`figures*` 等。**不包含**：`models_*`、权重、`deap_mat`、`*.dat`、`.git`、**`artifacts_binary_*`、`logs/`**、方案 A/B 与 smoke 等（见 `../package_tdmnn_course_report.sh`）。
