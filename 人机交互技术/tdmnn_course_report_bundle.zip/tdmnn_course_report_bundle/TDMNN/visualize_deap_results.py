#!/usr/bin/env python3
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/root/inpainting-work/interactive/TDMNN")
AROUSAL_JSON = BASE / "deap_arousal_full.json"
VALENCE_JSON = BASE / "deap_valence_full.json"
OUT_DIR = BASE / "figures"


def load_task(path: Path):
    with path.open("r", encoding="utf-8") as f:
        d = json.load(f)
    subjects = d["subjects"]
    sub_ids = sorted(subjects.keys(), key=lambda x: int(x))
    means = np.array([subjects[s]["mean"] for s in sub_ids], dtype=float)
    stds = np.array([subjects[s]["std"] for s in sub_ids], dtype=float)
    return d["task"], sub_ids, means, stds


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    task_a, sub_ids_a, means_a, stds_a = load_task(AROUSAL_JSON)
    task_v, sub_ids_v, means_v, stds_v = load_task(VALENCE_JSON)
    if sub_ids_a != sub_ids_v:
        raise RuntimeError("Subject IDs mismatch between arousal and valence results.")

    sub_ids = sub_ids_a
    x = np.arange(len(sub_ids))

    # 1) Overall bar chart with paper-style error bars (std over subject means)
    overall_means = np.array([means_a.mean(), means_v.mean()], dtype=float)
    overall_stds = np.array([means_a.std(ddof=0), means_v.std(ddof=0)], dtype=float)
    labels = ["Arousal", "Valence"]

    plt.figure(figsize=(6, 5))
    bars = plt.bar(labels, overall_means, yerr=overall_stds, capsize=8, color=["#f39c12", "#3498db"])
    plt.ylim(94, 100)
    plt.ylabel("Accuracy (%)")
    plt.title("DEAP Reproduction (Subject-Dependent, 5-Fold)")
    for b, m in zip(bars, overall_means):
        plt.text(b.get_x() + b.get_width() / 2.0, m + 0.08, f"{m:.2f}%", ha="center", va="bottom", fontsize=10)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "deap_overall_bar.png", dpi=180)
    plt.close()

    # 2) Subject-wise line plot
    plt.figure(figsize=(12, 5))
    plt.plot(x, means_a, marker="o", markersize=3, linewidth=1.4, label="Arousal", color="#f39c12")
    plt.plot(x, means_v, marker="o", markersize=3, linewidth=1.4, label="Valence", color="#3498db")
    plt.xticks(x, sub_ids, rotation=0, fontsize=8)
    plt.ylim(93, 100.5)
    plt.xlabel("Subject ID")
    plt.ylabel("Mean Accuracy over 5 folds (%)")
    plt.title("Subject-wise Accuracy")
    plt.grid(alpha=0.25, linestyle="--")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "deap_subject_line.png", dpi=180)
    plt.close()

    # 3) Subject-wise grouped bars with fold-std error bars
    width = 0.38
    plt.figure(figsize=(14, 5))
    plt.bar(x - width / 2, means_a, width=width, yerr=stds_a, capsize=2, color="#f5b041", label="Arousal")
    plt.bar(x + width / 2, means_v, width=width, yerr=stds_v, capsize=2, color="#5dade2", label="Valence")
    plt.xticks(x, sub_ids, fontsize=8)
    plt.ylim(93, 101)
    plt.xlabel("Subject ID")
    plt.ylabel("Accuracy (%)")
    plt.title("Per-subject Accuracy (bars) with 5-fold std (error bars)")
    plt.grid(axis="y", alpha=0.2, linestyle="--")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "deap_subject_grouped_bar.png", dpi=180)
    plt.close()

    # 4) Histogram distribution
    plt.figure(figsize=(8, 5))
    bins = np.linspace(93, 100, 15)
    plt.hist(means_a, bins=bins, alpha=0.7, label="Arousal", color="#f39c12")
    plt.hist(means_v, bins=bins, alpha=0.6, label="Valence", color="#3498db")
    plt.xlabel("Subject Mean Accuracy (%)")
    plt.ylabel("Count")
    plt.title("Distribution of Subject Mean Accuracies")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "deap_accuracy_hist.png", dpi=180)
    plt.close()

    # 5) Paper-style one-page summary figure
    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    bars = ax.bar(labels, overall_means, color=["#f39c12", "#3498db"], width=0.55)
    ax.set_ylim(94, 100)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("DEAP Binary Classification Summary (Paper-style)")
    ax.grid(axis="y", linestyle="--", alpha=0.25)

    for i, b in enumerate(bars):
        txt = f"{overall_means[i]:.2f} ± {overall_stds[i]:.2f}"
        ax.text(b.get_x() + b.get_width() / 2.0, b.get_height() + 0.08, txt, ha="center", va="bottom", fontsize=11)

    ax.text(
        0.02,
        0.02,
        "ACC = mean(subject means), STD = std(subject means), n=32",
        transform=ax.transAxes,
        fontsize=9,
        color="dimgray",
    )
    plt.tight_layout()
    plt.savefig(OUT_DIR / "deap_summary_single.png", dpi=220)
    plt.close()

    print("Saved figures to:", OUT_DIR)


if __name__ == "__main__":
    main()
