#!/usr/bin/env python3
"""
Aggregate binary TDMNN test predictions (npz from run_deap_original_style.py --artifacts-dir)
and compute/report the same style of metrics as course PDF: accuracy, precision, recall, F1, confusion matrix.

Outputs (under --out-dir):
  - binary_confusion_matrix.png
  - binary_metrics_bars.png
  - binary_metrics_from_preds.json
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--artifacts-dir", required=True, help="Directory containing preds_{v|a}_sXX_foldK.npz")
    ap.add_argument("--flag", choices=["v", "a"], required=True)
    ap.add_argument(
        "--out-dir",
        default="/root/inpainting-work/interactive/TDMNN/figures_binary",
        help="Directory for PNG + JSON summary.",
    )
    args = ap.parse_args()

    pattern = os.path.join(args.artifacts_dir, f"preds_{args.flag}_s*_fold*.npz")
    files = sorted(glob.glob(pattern))
    if not files:
        raise SystemExit(f"No prediction files match: {pattern}\nRun training first with:\n"
                         f"  python .../run_deap_original_style.py --flag {args.flag} --artifacts-dir {args.artifacts_dir} ...")

    y_true_all: list[np.ndarray] = []
    y_pred_all: list[np.ndarray] = []
    meta: list[dict] = []
    for fp in files:
        z = np.load(fp)
        y_true_all.append(z["y_true"].astype(int).ravel())
        y_pred_all.append(z["y_pred"].astype(int).ravel())
        m = re.search(r"_s(\d+)_fold(\d+)\.npz$", fp)
        meta.append({"file": os.path.basename(fp), "subject": m.group(1) if m else "", "fold": m.group(2) if m else ""})

    y_true = np.concatenate(y_true_all, axis=0)
    y_pred = np.concatenate(y_pred_all, axis=0)

    labels = [0, 1]
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    acc = float(accuracy_score(y_true, y_pred))
    p_macro, r_macro, f_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", labels=labels, zero_division=0
    )
    report = classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    task_name = "valence" if args.flag == "v" else "arousal"
    class_names = ["low (<=5)", "high (>5)"] if args.flag == "v" else ["low (<=5)", "high (>5)"]

    summary = {
        "task": f"binary_{task_name}",
        "n_samples": int(len(y_true)),
        "n_files": len(files),
        "accuracy": acc,
        "precision_macro": float(p_macro),
        "recall_macro": float(r_macro),
        "f1_macro": float(f_macro),
        "confusion_matrix": cm.tolist(),
        "class_names": class_names,
        "classification_report": report,
        "source_files": [m["file"] for m in meta],
    }
    json_path = out_dir / f"binary_metrics_from_preds_{task_name}.json"
    json_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Wrote", json_path)

    # --- Confusion matrix heatmap (counts + row-normalized inset via text) ---
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    ax.figure.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    tick_marks = np.arange(len(class_names))
    ax.set_xticks(tick_marks)
    ax.set_yticks(tick_marks)
    ax.set_xticklabels(class_names, rotation=20, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_ylabel("True")
    ax.set_xlabel("Predicted")
    thresh = cm.max() / 2.0 if cm.size else 0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, format(cm[i, j], "d"), ha="center", va="center", color="white" if cm[i, j] > thresh else "black")
    ax.set_title(f"DEAP Binary {task_name.title()} — Confusion (all folds, pooled)")
    fig.tight_layout()
    p_cm = out_dir / f"binary_{task_name}_confusion_matrix.png"
    fig.savefig(p_cm, dpi=220)
    plt.close(fig)
    print("Wrote", p_cm)

    # --- Bar chart: Acc + macro P/R/F1 ---
    names = ["Accuracy", "Precision\n(macro)", "Recall\n(macro)", "F1\n(macro)"]
    vals = np.array([acc, p_macro, r_macro, f_macro], dtype=float) * 100.0
    fig, ax = plt.subplots(figsize=(6.2, 4.4))
    colors = ["#3498db", "#2ecc71", "#e67e22", "#9b59b6"]
    ax.bar(names, vals, color=colors, width=0.65)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Score (%)")
    ax.set_title(f"DEAP Binary {task_name.title()} — Summary metrics (pooled)")
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    for i, v in enumerate(vals):
        ax.text(i, v + 1.2, f"{v:.2f}", ha="center", va="bottom", fontsize=10)
    fig.tight_layout()
    p_bar = out_dir / f"binary_{task_name}_metrics_bars.png"
    fig.savefig(p_bar, dpi=220)
    plt.close(fig)
    print("Wrote", p_bar)


if __name__ == "__main__":
    main()
