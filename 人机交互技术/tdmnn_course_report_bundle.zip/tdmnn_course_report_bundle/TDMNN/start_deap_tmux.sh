#!/usr/bin/env bash
# 在 tmux 中并行跑 DEAP：Arousal 用 GPU0+1，Valence 用 GPU2+3。
# 遵守共享服务器 tmux 规则：仅 new-session / kill-session(本会话名) / capture-pane。

set -euo pipefail
ROOT="/root/inpainting-work"
LOG="$ROOT/interactive/TDMNN/logs"
mkdir -p "$LOG"

SESS_A="tdmnn_deap_a"
SESS_V="tdmnn_deap_v"

for s in "$SESS_A" "$SESS_V"; do
  if tmux has-session -t "$s" 2>/dev/null; then
    tmux kill-session -t "$s"
  fi
done

# 宽屏创建，避免进度条被截断（见项目规则）
tmux new-session -d -s "$SESS_A" -x 250 -y 50 \
  "cd \"$ROOT\" && export TF_USE_LEGACY_KERAS=1 CUDA_VISIBLE_DEVICES=0,1 && exec python interactive/TDMNN/run_deap_original_style.py --flag a --subjects all --epochs 50 --batch-size 128 --out-json interactive/TDMNN/deap_arousal_full.json 2>&1 | tee \"$LOG/deap_arousal.log\""

tmux new-session -d -s "$SESS_V" -x 250 -y 50 \
  "cd \"$ROOT\" && export TF_USE_LEGACY_KERAS=1 CUDA_VISIBLE_DEVICES=2,3 && exec python interactive/TDMNN/run_deap_original_style.py --flag v --subjects all --epochs 50 --batch-size 128 --out-json interactive/TDMNN/deap_valence_full.json 2>&1 | tee \"$LOG/deap_valence.log\""

echo "Started tmux sessions:"
tmux ls 2>/dev/null | grep -E "tdmnn_deap" || true
echo ""
echo "Logs:"
echo "  $LOG/deap_arousal.log"
echo "  $LOG/deap_valence.log"
echo ""
echo "查看进度: tail -f $LOG/deap_arousal.log"
echo "查看会话: tmux capture-pane -t $SESS_A -p | tail -40"
