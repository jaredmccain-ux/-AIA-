#!/usr/bin/env python3
"""
Compute paper/report metrics from saved results.

- Binary: only accuracy stats from existing *_full.json (no predictions saved).
- 3-class valence: compute accuracy, macro precision/recall/F1 and confusion matrix
  by re-running inference using saved fold checkpoints.
"""

from __future__ import annotations

import csv
import json
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import scipy.io as sio
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import StratifiedKFold

import tensorflow as tf


BASE = Path("/root/inpainting-work/interactive/TDMNN")
DAT_DIR = Path("/root/inpainting-work/interactive/new/data_preprocessed_custom")
MAT_DIR = BASE / "deap_mat"


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def subj_ids_from_binary_json(path: Path) -> List[str]:
    d = load_json(path)
    return sorted(d["subjects"].keys(), key=lambda x: int(x))


def rating_to_three_class(v: float, low: float, high: float) -> int:
    if v < low:
        return 0
    if v < high:
        return 1
    return 2


def build_threeclass_seq_labels_from_dat(dat_path: Path, low: float, high: float, t: int = 6) -> np.ndarray:
    with open(dat_path, "rb") as f:
        obj = pickle.load(f, encoding="latin1")
    labels = np.asarray(obj["labels"], dtype=float)  # (40,4)
    trial_scores = labels[:, 0]  # valence
    window_scores = np.repeat(trial_scores, 120)  # 40*120
    seq = np.array([rating_to_three_class(float(window_scores[j * t]), low, high) for j in range(len(window_scores) // t)], dtype=int)
    return seq


def load_x_from_mat(mat_path: Path, t: int = 6) -> np.ndarray:
    file = sio.loadmat(mat_path)
    data = file["data"]  # (4800,4,8,9)
    x = data.transpose([0, 2, 3, 1]).reshape((-1, t, 8, 9, 4))
    return x


def vote_preds(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> np.ndarray:
    out = np.zeros_like(p1)
    for i in range(len(out)):
        if p1[i] == p2[i]:
            out[i] = p1[i]
        elif p1[i] == p3[i]:
            out[i] = p1[i]
        elif p2[i] == p3[i]:
            out[i] = p2[i]
        else:
            out[i] = p1[i]
    return out


@dataclass
class MetricRow:
    task: str
    metric: str
    value: float


def main() -> None:
    out_dir = BASE / "tables"
    out_dir.mkdir(parents=True, exist_ok=True)

    # -------- Binary (from JSON only) --------
    rows: List[Dict[str, object]] = []
    for task, path in [
        ("binary_arousal", BASE / "deap_arousal_full.json"),
        ("binary_valence", BASE / "deap_valence_full.json"),
    ]:
        d = load_json(path)
        acc = np.asarray(d["acc_all"], dtype=float)
        within = np.asarray(d["std_all"], dtype=float)
        rows.append({"task": task, "metric": "acc_mean_subject", "value": float(acc.mean())})
        rows.append({"task": task, "metric": "std_subject", "value": float(acc.std(ddof=0))})
        rows.append({"task": task, "metric": "std_within_subject_mean", "value": float(within.mean())})

    # -------- 3-class valence (recompute predictions from saved checkpoints) --------
    tri_json = BASE / "deap_valence_3class.json"
    tri = load_json(tri_json)
    low = float(tri["thresholds"]["low"])
    high = float(tri["thresholds"]["high"])

    subj_ids = sorted(tri["subjects"].keys(), key=lambda x: int(x))
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=7)

    cm_total = np.zeros((3, 3), dtype=int)
    p_list: List[float] = []
    r_list: List[float] = []
    f1_list: List[float] = []
    acc_list: List[float] = []

    model_root = BASE / "models_threeclass_valence"

    for sid in subj_ids:
        x = load_x_from_mat(MAT_DIR / f"DE_s{sid}.mat", t=6)
        y = build_threeclass_seq_labels_from_dat(DAT_DIR / f"s{sid}.dat", low=low, high=high, t=6)

        for fold_idx, (train_idx, test_idx) in enumerate(skf.split(x, y), start=1):
            fold_dir = model_root / f"subject_{sid}" / f"fold_{fold_idx}"
            m1 = tf.keras.models.load_model(fold_dir / "best_model1.keras", compile=False)
            m2 = tf.keras.models.load_model(fold_dir / "best_model2.keras", compile=False)
            m3 = tf.keras.models.load_model(fold_dir / "best_model3.keras", compile=False)

            x_test = x[test_idx]
            x_test_in = [x_test[:, i] for i in range(6)]
            y_true = y[test_idx]

            p1 = np.argmax(m1.predict(x_test_in, verbose=0), axis=1)
            p2 = np.argmax(m2.predict(x_test_in, verbose=0), axis=1)
            p3 = np.argmax(m3.predict(x_test_in, verbose=0), axis=1)
            y_pred = vote_preds(p1, p2, p3)

            cm_total += confusion_matrix(y_true, y_pred, labels=[0, 1, 2])
            p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
            acc = float((y_true == y_pred).mean())
            p_list.append(float(p))
            r_list.append(float(r))
            f1_list.append(float(f1))
            acc_list.append(acc)

    rows.append({"task": "valence_3class", "metric": "acc_macro_over_folds", "value": float(np.mean(acc_list)) * 100.0})
    rows.append({"task": "valence_3class", "metric": "precision_macro_over_folds", "value": float(np.mean(p_list)) * 100.0})
    rows.append({"task": "valence_3class", "metric": "recall_macro_over_folds", "value": float(np.mean(r_list)) * 100.0})
    rows.append({"task": "valence_3class", "metric": "f1_macro_over_folds", "value": float(np.mean(f1_list)) * 100.0})

    # Save confusion matrix separately
    cm_path = out_dir / "valence_3class_confusion_matrix.json"
    cm_path.write_text(json.dumps({"labels": ["low", "mid", "high"], "matrix": cm_total.tolist()}, indent=2), encoding="utf-8")

    # Write metric table
    csv_path = out_dir / "metrics_summary.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["task", "metric", "value"])
        w.writeheader()
        w.writerows(rows)

    json_path = out_dir / "metrics_summary.json"
    json_path.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")

    print("Wrote", csv_path)
    print("Wrote", json_path)
    print("Wrote", cm_path)


if __name__ == "__main__":
    main()

