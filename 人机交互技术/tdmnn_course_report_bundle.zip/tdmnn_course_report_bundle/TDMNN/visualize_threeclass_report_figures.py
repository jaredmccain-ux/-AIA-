#!/usr/bin/env python3
"""
Build publication-style figures for 3-class valence from existing tabulated outputs
(no model checkpoints needed):
  - Confusion matrix (from tables/valence_3class_confusion_matrix.json)
  - Macro Precision / Recall / F1 / Accuracy bars (from tables/metrics_summary.json)
Outputs to: interactive/TDMNN/figures_threeclass/
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/root/inpainting-work/interactive/TDMNN")
CM_JSON = BASE / "tables" / "valence_3class_confusion_matrix.json"
METRICS_JSON = BASE / "tables" / "metrics_summary.json"
OUT_DIR = BASE / "figures_threeclass"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    if not CM_JSON.is_file():
        raise SystemExit(f"Missing {CM_JSON}. Run tabulate_metrics.py first.")
    cm_obj = json.loads(CM_JSON.read_text(encoding="utf-8"))
    labels = cm_obj["labels"]
    cm = np.asarray(cm_obj["matrix"], dtype=float)

    # --- Confusion matrix ---
    fig, ax = plt.subplots(figsize=(5.8, 4.8))
    im = ax.imshow(cm, interpolation="nearest", cmap="Greens")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ticks = np.arange(len(labels))
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)
    ax.set_xticklabels(labels, rotation=15, ha="right")
    ax.set_yticklabels(labels)
    ax.set_ylabel("True")
    ax.set_xlabel("Predicted")
    mx = cm.max() if cm.size else 1.0
    thresh = mx / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(
                j, i, format(int(cm[i, j]), "d"),
                ha="center", va="center",
                color="white" if cm[i, j] > thresh else "black",
            )
    ax.set_title("DEAP Valence 3-class — Confusion matrix (pooled)")
    fig.tight_layout()
    p1 = OUT_DIR / "threeclass_valence_confusion_matrix.png"
    fig.savefig(p1, dpi=220)
    plt.close(fig)
    print("Wrote", p1)

    # --- Metrics bars from metrics_summary.json ---
    if not METRICS_JSON.is_file():
        print("Skip metrics bars: missing", METRICS_JSON)
        return

    rows = json.loads(METRICS_JSON.read_text(encoding="utf-8"))
    wanted = {
        "valence_3class|acc_macro_over_folds": "Accuracy (macro over folds)",
        "valence_3class|precision_macro_over_folds": "Precision (macro)",
        "valence_3class|recall_macro_over_folds": "Recall (macro)",
        "valence_3class|f1_macro_over_folds": "F1 (macro)",
    }
    vals = []
    names = []
    for r in rows:
        key = f"{r['task']}|{r['metric']}"
        if key in wanted:
            names.append(wanted[key])
            vals.append(float(r["value"]))  # already % in tabulate_metrics

    if len(vals) != 4:
        raise SystemExit(f"Could not find all valence_3class metrics in {METRICS_JSON}, got keys: {[r for r in rows if r['task']=='valence_3class']}")

    fig, ax = plt.subplots(figsize=(7.0, 4.5))
    x = np.arange(len(names))
    ax.bar(x, vals, color=["#2e86c1", "#27ae60", "#e67e22", "#8e44ad"], width=0.55)
    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=9)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Score (%)")
    ax.set_title("DEAP Valence 3-class — Macro metrics (from saved checkpoints eval)")
    ax.grid(axis="y", linestyle="--", alpha=0.3)
    for i, v in enumerate(vals):
        ax.text(i, v + 1.0, f"{v:.2f}", ha="center", va="bottom", fontsize=10)
    fig.tight_layout()
    p2 = OUT_DIR / "threeclass_valence_metrics_bars.png"
    fig.savefig(p2, dpi=220)
    plt.close(fig)
    print("Wrote", p2)


if __name__ == "__main__":
    main()
