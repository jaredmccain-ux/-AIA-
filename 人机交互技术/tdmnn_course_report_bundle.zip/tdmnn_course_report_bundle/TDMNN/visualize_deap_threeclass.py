#!/usr/bin/env python3
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/root/inpainting-work/interactive/TDMNN")
IN_JSON = BASE / "deap_valence_3class.json"
OUT_DIR = BASE / "figures"


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    with IN_JSON.open("r", encoding="utf-8") as f:
        d = json.load(f)

    acc_avg = float(d["acc_avg"])
    std_subject = float(d.get("std_subject", np.nan))
    low = d.get("thresholds", {}).get("low", None)
    high = d.get("thresholds", {}).get("high", None)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.bar(["Valence (3-class)"], [acc_avg], color="#2e86c1", width=0.5)
    ax.set_ylim(90, 100)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("DEAP Valence 3-class Summary (Subject-Dependent, 5-Fold)")
    ax.grid(axis="y", linestyle="--", alpha=0.25)

    txt = f"{acc_avg:.2f} ± {std_subject:.2f}"
    ax.text(0, acc_avg + 0.15, txt, ha="center", va="bottom", fontsize=13)

    note = "ACC = mean(subject means), STD = std(subject means), n=32"
    if low is not None and high is not None:
        note += f" | thresholds: <{low} / [{low},{high}) / ≥{high}"
    ax.text(0.02, 0.02, note, transform=ax.transAxes, fontsize=9, color="dimgray")

    plt.tight_layout()
    out_path = OUT_DIR / "deap_valence_3class_summary.png"
    plt.savefig(out_path, dpi=220)
    plt.close()
    print("Saved:", out_path)


if __name__ == "__main__":
    main()

