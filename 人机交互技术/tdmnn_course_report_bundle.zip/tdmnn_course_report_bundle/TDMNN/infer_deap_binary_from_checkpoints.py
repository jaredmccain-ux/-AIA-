#!/usr/bin/env python3
"""
Load saved TDMNN binary checkpoints (best_model1/2/3) and run inference only — no training.

Uses the SAME subject-dependent 5-fold split as run_deap_original_style.py:
  StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)

Writes per-fold npz compatible with plot_deap_binary_metrics.py:
  preds_{v|a}_s{sid}_fold{k}.npz  -> y_true, y_pred (int64 class ids)

Typical model dirs (from start_deap_binary_tmux.sh):
  models_binary_valence  /  models_binary_arousal
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import List, Tuple

import numpy as np
import scipy.io as sio
import tensorflow as tf
from sklearn.model_selection import StratifiedKFold
from tensorflow.keras import backend as K
from tensorflow.keras.utils import to_categorical

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"


def vote_preds(p1: np.ndarray, p2: np.ndarray, p3: np.ndarray) -> np.ndarray:
    out = np.zeros_like(p1)
    for i in range(len(out)):
        if p1[i] == p2[i]:
            out[i] = p1[i]
        elif p1[i] == p3[i]:
            out[i] = p1[i]
        elif p2[i] == p3[i]:
            out[i] = p2[i]
        else:
            out[i] = p1[i]
    return out


def load_xy(mat_path: str, flag: str, t: int = 6) -> Tuple[np.ndarray, np.ndarray]:
    file = sio.loadmat(mat_path)
    data = file["data"]
    y_v = to_categorical(file["valence_labels"][0], 2)
    y_a = to_categorical(file["arousal_labels"][0], 2)
    x = data.transpose([0, 2, 3, 1]).reshape((-1, t, 8, 9, 4))
    y_v2 = np.vstack([y_v[j * t] for j in range(len(y_v) // t)])
    y_a2 = np.vstack([y_a[j * t] for j in range(len(y_a) // t)])
    y = y_v2 if flag == "v" else y_a2
    return x, y


def resolve_model_path(fold_dir: Path, branch: int) -> Path:
    for ext in (".keras", ".h5"):
        p = fold_dir / f"best_model{branch}{ext}"
        if p.is_file():
            return p
    raise FileNotFoundError(f"No best_model{branch}.keras or .h5 in {fold_dir}")


def infer_subject(
    mat_path: str,
    flag: str,
    model_dir: str,
    subject_id: str,
    artifacts_dir: str,
    seed: int = 7,
) -> List[float]:
    x, y = load_xy(mat_path, flag)
    np.random.seed(seed)
    kfold = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    fold_scores: List[float] = []
    os.makedirs(artifacts_dir, exist_ok=True)

    for fold_idx, (_, test) in enumerate(kfold.split(x, y.argmax(1)), start=1):
        K.clear_session()
        fold_dir = Path(model_dir) / f"subject_{subject_id}" / f"fold_{fold_idx}"
        if not fold_dir.is_dir():
            raise FileNotFoundError(f"Missing checkpoint dir: {fold_dir}")

        m1 = tf.keras.models.load_model(resolve_model_path(fold_dir, 1), compile=False)
        m2 = tf.keras.models.load_model(resolve_model_path(fold_dir, 2), compile=False)
        m3 = tf.keras.models.load_model(resolve_model_path(fold_dir, 3), compile=False)

        x_test = x[test]
        y_test = y[test]
        x_test_in = [x_test[:, i] for i in range(6)]
        true = np.argmax(y_test, axis=1)

        p1 = np.argmax(m1.predict(x_test_in, verbose=0), axis=1)
        p2 = np.argmax(m2.predict(x_test_in, verbose=0), axis=1)
        p3 = np.argmax(m3.predict(x_test_in, verbose=0), axis=1)
        vote = vote_preds(p1, p2, p3)
        score = float((vote == true).mean() * 100.0)
        fold_scores.append(score)

        fn = os.path.join(artifacts_dir, f"preds_{flag}_s{subject_id}_fold{fold_idx}.npz")
        np.savez_compressed(fn, y_true=true.astype(np.int64), y_pred=vote.astype(np.int64))
        print(f"  s{subject_id} fold {fold_idx}: acc={score:.2f}% -> {fn}")

    return fold_scores


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-dir", default="/root/inpainting-work/interactive/TDMNN/deap_mat")
    ap.add_argument("--flag", choices=["v", "a"], required=True)
    ap.add_argument(
        "--model-dir",
        required=True,
        help="e.g. interactive/TDMNN/models_binary_valence or models_binary_arousal",
    )
    ap.add_argument("--artifacts-dir", required=True, help="Where to write preds_*.npz")
    ap.add_argument("--subjects", default="all")
    ap.add_argument("--seed", type=int, default=7, help="Must match training StratifiedKFold random_state.")
    ap.add_argument(
        "--out-json",
        default=None,
        help="Optional: write same-style summary JSON as run_deap_original_style (subject means).",
    )
    args = ap.parse_args()

    if args.subjects == "all":
        subs = [f"{i:02d}" for i in range(1, 33)]
    else:
        subs = [f"{int(s):02d}" for s in args.subjects.split(",") if s.strip()]

    all_means: List[float] = []
    all_stds: List[float] = []
    details = {}

    for sid in subs:
        mat_path = os.path.join(args.dataset_dir, f"DE_s{sid}.mat")
        if not os.path.exists(mat_path):
            print(f"skip s{sid}: no mat")
            continue
        print(f"\ninfer s{sid} ...")
        scores = infer_subject(
            mat_path,
            args.flag,
            os.path.expanduser(args.model_dir),
            sid,
            args.artifacts_dir,
            seed=args.seed,
        )
        m = float(np.mean(scores))
        s = float(np.std(scores))
        all_means.append(m)
        all_stds.append(s)
        details[sid] = {"fold_scores": scores, "mean": m, "std": s}

    if args.out_json:
        out = {
            "task": "valence" if args.flag == "v" else "arousal",
            "source": "inference_from_checkpoints_only",
            "model_dir": args.model_dir,
            "subjects": details,
            "acc_all": all_means,
            "std_all": all_stds,
            "acc_avg": float(np.mean(all_means)) if all_means else None,
            "std_subject": float(np.std(all_means)) if all_means else None,
            "std_avg": float(np.mean(all_stds)) if all_stds else None,
        }
        Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
        with open(args.out_json, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2, ensure_ascii=False)
        print("\nsaved summary:", args.out_json)

    print("\nAcc_all (subject means):", all_means)
    print("acc_avg:", float(np.mean(all_means)) if all_means else None)


if __name__ == "__main__":
    main()
