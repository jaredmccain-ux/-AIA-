#!/usr/bin/env bash
# Run DEAP binary reproduction in tmux with 4 GPUs:
# - Arousal: GPU 0,1
# - Valence: GPU 2,3
#
# Safe tmux ops only: new-session / kill-session (own sessions) / capture-pane.

set -euo pipefail

ROOT="/root/inpainting-work"
LOG_DIR="$ROOT/interactive/TDMNN/logs"
mkdir -p "$LOG_DIR"

SESS_A="tdmnn_bin_a"
SESS_V="tdmnn_bin_v"

for s in "$SESS_A" "$SESS_V"; do
  if tmux has-session -t "$s" 2>/dev/null; then
    tmux kill-session -t "$s"
  fi
done

# Create wide sessions to avoid truncation.
tmux new-session -d -s "$SESS_A" -x 250 -y 50 \
  "cd \"$ROOT\" && export TF_USE_LEGACY_KERAS=1 CUDA_VISIBLE_DEVICES=0,1 && \
   exec python interactive/TDMNN/run_deap_original_style.py \
     --flag a --subjects all --epochs 50 --batch-size 128 \
     --save-models --model-dir \"$ROOT/interactive/TDMNN/models_binary_arousal\" \
     --out-json \"$ROOT/interactive/TDMNN/deap_arousal_full_saved.json\" \
   2>&1 | tee \"$LOG_DIR/deap_binary_arousal_saved.log\""

tmux new-session -d -s "$SESS_V" -x 250 -y 50 \
  "cd \"$ROOT\" && export TF_USE_LEGACY_KERAS=1 CUDA_VISIBLE_DEVICES=2,3 && \
   exec python interactive/TDMNN/run_deap_original_style.py \
     --flag v --subjects all --epochs 50 --batch-size 128 \
     --save-models --model-dir \"$ROOT/interactive/TDMNN/models_binary_valence\" \
     --out-json \"$ROOT/interactive/TDMNN/deap_valence_full_saved.json\" \
   2>&1 | tee \"$LOG_DIR/deap_binary_valence_saved.log\""

echo "Started tmux sessions:"
tmux ls 2>/dev/null | grep -E "tdmnn_bin_" || true
echo ""
echo "Logs:"
echo "  $LOG_DIR/deap_binary_arousal_saved.log"
echo "  $LOG_DIR/deap_binary_valence_saved.log"
echo ""
echo "Progress:"
echo "  tmux capture-pane -t $SESS_A -p | tail -40"
echo "  tmux capture-pane -t $SESS_V -p | tail -40"

