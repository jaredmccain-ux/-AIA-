#!/usr/bin/env python3
"""
Regenerate *all* figures from saved JSON results with unambiguous definitions.

Outputs to: interactive/TDMNN/figures/

Figures:
  - binary_overview.png: two bars (Arousal/Valence) with text "mean ± std_subject"
  - binary_subject_means.png: subject-wise mean accuracy lines (A/V)
  - binary_subject_hist.png: histogram of subject-mean accuracies (A/V)
  - threeclass_valence_overview.png: single bar with "mean ± std_subject" + thresholds
  - class_counts_binary.png: overall class counts (sequence-level) for binary V/A (threshold=5)
  - class_counts_threeclass_valence.png: overall class counts (sequence-level) for 3-class valence (low/high)
"""

from __future__ import annotations

import json
import pickle
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/root/inpainting-work/interactive/TDMNN")
FIG = BASE / "figures"

BIN_A = BASE / "deap_arousal_full.json"
BIN_V = BASE / "deap_valence_full.json"
TRI_V = BASE / "deap_valence_3class.json"

DAT_DIR = Path("/root/inpainting-work/interactive/new/data_preprocessed_custom")


def load_subject_means(path: Path) -> tuple[str, list[str], np.ndarray]:
    d = json.loads(path.read_text(encoding="utf-8"))
    subjects = d["subjects"]
    sub_ids = sorted(subjects.keys(), key=lambda x: int(x))
    means = np.array([subjects[s]["mean"] for s in sub_ids], dtype=float)
    return d["task"], sub_ids, means


def read_trial_scores_from_dat(sid: str) -> np.ndarray:
    dat_path = DAT_DIR / f"s{sid}.dat"
    with open(dat_path, "rb") as f:
        obj = pickle.load(f, encoding="latin1")
    labels = np.asarray(obj["labels"], dtype=float)  # (40,4)
    return labels[:, :2]  # valence, arousal


def sequence_labels_binary(trial_scores: np.ndarray, threshold: float = 5.0, t: int = 6) -> np.ndarray:
    # trial_scores: (40,) in [1..9]
    window_labels = np.repeat(trial_scores, 120)  # 40 trials * 120 windows
    seq = np.array([(window_labels[j * t] > threshold) for j in range(len(window_labels) // t)], dtype=int)
    return seq


def sequence_labels_threeclass(trial_scores: np.ndarray, low: float, high: float, t: int = 6) -> np.ndarray:
    window_labels = np.repeat(trial_scores, 120)
    def to3(v: float) -> int:
        if v < low:
            return 0
        if v < high:
            return 1
        return 2
    seq = np.array([to3(float(window_labels[j * t])) for j in range(len(window_labels) // t)], dtype=int)
    return seq


def main() -> None:
    FIG.mkdir(parents=True, exist_ok=True)

    # ---------- Binary figures ----------
    _, sub_ids_a, means_a = load_subject_means(BIN_A)
    _, sub_ids_v, means_v = load_subject_means(BIN_V)
    if sub_ids_a != sub_ids_v:
        raise RuntimeError("Binary subject id mismatch.")

    acc_a = float(means_a.mean())
    std_a = float(means_a.std(ddof=0))  # subject-wise std (paper-style)
    acc_v = float(means_v.mean())
    std_v = float(means_v.std(ddof=0))

    # Overview (no error bars, only text)
    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    labels = ["Arousal (2-class)", "Valence (2-class)"]
    vals = [acc_a, acc_v]
    colors = ["#f39c12", "#3498db"]
    bars = ax.bar(labels, vals, color=colors, width=0.55)
    ax.set_ylim(94, 100)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("DEAP Binary Summary (subject-dependent, 5-fold)")
    ax.grid(axis="y", linestyle="--", alpha=0.25)
    for i, b in enumerate(bars):
        txt = f"{vals[i]:.2f} ± {[std_a, std_v][i]:.2f}"
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.12, txt, ha="center", va="bottom", fontsize=12)
    ax.text(0.02, 0.02, "± is STD over subject means (n=32)", transform=ax.transAxes, fontsize=9, color="dimgray")
    plt.tight_layout()
    plt.savefig(FIG / "binary_overview.png", dpi=220)
    plt.close()

    # Subject-wise means line plot
    x = np.arange(len(sub_ids_a))
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(x, means_a, marker="o", markersize=3, linewidth=1.4, label="Arousal", color=colors[0])
    ax.plot(x, means_v, marker="o", markersize=3, linewidth=1.4, label="Valence", color=colors[1])
    ax.set_xticks(x)
    ax.set_xticklabels(sub_ids_a, fontsize=8)
    ax.set_ylim(93, 100.5)
    ax.set_xlabel("Subject ID")
    ax.set_ylabel("Mean accuracy over 5 folds (%)")
    ax.set_title("Binary: subject-wise mean accuracies")
    ax.grid(alpha=0.25, linestyle="--")
    ax.legend()
    plt.tight_layout()
    plt.savefig(FIG / "binary_subject_means.png", dpi=200)
    plt.close()

    # Histogram of subject means
    fig, ax = plt.subplots(figsize=(8, 5))
    bins = np.linspace(93, 100, 15)
    ax.hist(means_a, bins=bins, alpha=0.7, label="Arousal", color=colors[0])
    ax.hist(means_v, bins=bins, alpha=0.6, label="Valence", color=colors[1])
    ax.set_xlabel("Subject mean accuracy (%)")
    ax.set_ylabel("Count")
    ax.set_title("Binary: distribution of subject mean accuracies")
    ax.legend()
    plt.tight_layout()
    plt.savefig(FIG / "binary_subject_hist.png", dpi=200)
    plt.close()

    # ---------- Three-class figures ----------
    tri = json.loads(TRI_V.read_text(encoding="utf-8"))
    tri_means = np.array(tri["acc_all"], dtype=float)
    tri_acc = float(tri_means.mean())
    tri_std = float(tri_means.std(ddof=0))
    low = float(tri["thresholds"]["low"])
    high = float(tri["thresholds"]["high"])

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.bar(["Valence (3-class)"], [tri_acc], color="#2e86c1", width=0.5)
    ax.set_ylim(90, 100)
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("DEAP Valence 3-class Summary (subject-dependent, 5-fold)")
    ax.grid(axis="y", linestyle="--", alpha=0.25)
    ax.text(0, tri_acc + 0.15, f"{tri_acc:.2f} ± {tri_std:.2f}", ha="center", va="bottom", fontsize=13)
    ax.text(
        0.02,
        0.02,
        f"± is STD over subject means (n=32) | thresholds: <{low} / [{low},{high}) / ≥{high}",
        transform=ax.transAxes,
        fontsize=9,
        color="dimgray",
    )
    plt.tight_layout()
    plt.savefig(FIG / "threeclass_valence_overview.png", dpi=220)
    plt.close()

    # ---------- Class count statistics ----------
    # Binary counts (sequence-level, per subject then summed)
    counts_v = np.zeros(2, dtype=int)
    counts_a = np.zeros(2, dtype=int)
    for sid in sub_ids_a:
        scores = read_trial_scores_from_dat(sid)
        seq_v = sequence_labels_binary(scores[:, 0], threshold=5.0, t=6)
        seq_a = sequence_labels_binary(scores[:, 1], threshold=5.0, t=6)
        counts_v += np.bincount(seq_v, minlength=2)
        counts_a += np.bincount(seq_a, minlength=2)

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    x = np.arange(2)
    w = 0.35
    ax.bar(x - w / 2, counts_a, width=w, label="Arousal", color=colors[0])
    ax.bar(x + w / 2, counts_v, width=w, label="Valence", color=colors[1])
    ax.set_xticks(x)
    ax.set_xticklabels(["Low (≤5)", "High (>5)"])
    ax.set_ylabel("Sequence sample count")
    ax.set_title("Binary: class counts (sequence-level, all subjects)")
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.2)
    plt.tight_layout()
    plt.savefig(FIG / "class_counts_binary.png", dpi=220)
    plt.close()

    # Three-class counts (valence only, sequence-level)
    counts_3 = np.zeros(3, dtype=int)
    for sid in sub_ids_a:
        scores = read_trial_scores_from_dat(sid)
        seq3 = sequence_labels_threeclass(scores[:, 0], low=low, high=high, t=6)
        counts_3 += np.bincount(seq3, minlength=3)

    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.bar(["Low", "Mid", "High"], counts_3, color=["#5dade2", "#48c9b0", "#f5b041"])
    ax.set_ylabel("Sequence sample count")
    ax.set_title(f"Valence 3-class: class counts (sequence-level, all subjects) | low={low}, high={high}")
    ax.grid(axis="y", linestyle="--", alpha=0.2)
    for i, c in enumerate(counts_3):
        ax.text(i, c + max(counts_3) * 0.01, str(int(c)), ha="center", va="bottom", fontsize=10)
    plt.tight_layout()
    plt.savefig(FIG / "class_counts_threeclass_valence.png", dpi=220)
    plt.close()

    print("Wrote figures to", FIG)


if __name__ == "__main__":
    main()

