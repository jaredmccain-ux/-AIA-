#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/root/inpainting-work/interactive/TDMNN")
TABLES = BASE / "tables"
FIG = BASE / "figures"


def load_metrics_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def fmt_value(metric: str, value: float) -> str:
    # Accuracy-like metrics in %
    if metric.startswith("acc_") or "precision" in metric or "recall" in metric or "f1" in metric:
        return f"{value:.2f}"
    return f"{value:.4f}"


def build_metrics_table(rows: list[dict[str, str]]) -> tuple[list[str], list[list[str]]]:
    # Reformat into a compact table for reports
    by_task: dict[str, dict[str, float]] = {}
    for r in rows:
        task = r["task"]
        metric = r["metric"]
        value = float(r["value"])
        by_task.setdefault(task, {})[metric] = value

    header = ["Task", "ACC(mean)", "STD_subject", "STD_within_subject_mean", "P_macro", "R_macro", "F1_macro"]
    table_rows: list[list[str]] = []

    def get(task: str, metric: str) -> str:
        v = by_task.get(task, {}).get(metric, None)
        if v is None:
            return "-"
        return fmt_value(metric, float(v))

    for task in ["binary_arousal", "binary_valence", "valence_3class"]:
        table_rows.append(
            [
                task,
                get(task, "acc_mean_subject") if task.startswith("binary") else get(task, "acc_macro_over_folds"),
                get(task, "std_subject"),
                get(task, "std_within_subject_mean"),
                get(task, "precision_macro_over_folds"),
                get(task, "recall_macro_over_folds"),
                get(task, "f1_macro_over_folds"),
            ]
        )

    return header, table_rows


def render_table_png(title: str, header: list[str], rows: list[list[str]], out_path: Path) -> None:
    FIG.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(13.5, 3.6))
    ax.axis("off")
    ax.set_title(title, fontsize=14, pad=12)

    # Create table
    table = ax.table(
        cellText=rows,
        colLabels=header,
        cellLoc="center",
        colLoc="center",
        loc="center",
    )
    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1.0, 1.5)

    # Style header row
    for (r, c), cell in table.get_celld().items():
        if r == 0:
            cell.set_text_props(weight="bold", color="white")
            cell.set_facecolor("#2c3e50")
        else:
            if r % 2 == 1:
                cell.set_facecolor("#f2f2f2")

    # Footnote
    ax.text(
        0.01,
        0.02,
        "Notes: ACC/STD are in %. For binary tasks, P/R/F1 require saved predictions or re-inference; shown '-' if unavailable.",
        transform=ax.transAxes,
        fontsize=9,
        color="dimgray",
    )

    plt.tight_layout()
    plt.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close()


def render_confusion_matrix(cm_path: Path, out_path: Path) -> None:
    FIG.mkdir(parents=True, exist_ok=True)
    d = json.loads(cm_path.read_text(encoding="utf-8"))
    labels = d["labels"]
    cm = np.array(d["matrix"], dtype=int)

    fig, ax = plt.subplots(figsize=(6.4, 5.6))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_title("Valence 3-class Confusion Matrix (aggregated)", pad=10)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels)
    ax.set_yticklabels(labels)

    # annotate
    maxv = cm.max() if cm.size else 1
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            color = "white" if cm[i, j] > 0.55 * maxv else "black"
            ax.text(j, i, f"{cm[i, j]}", ha="center", va="center", color=color, fontsize=11)

    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(out_path, dpi=220, bbox_inches="tight")
    plt.close()


def main() -> None:
    metrics_csv = TABLES / "metrics_summary.csv"
    cm_json = TABLES / "valence_3class_confusion_matrix.json"

    rows = load_metrics_csv(metrics_csv)
    header, table_rows = build_metrics_table(rows)
    render_table_png(
        title="DEAP Results Summary (table view)",
        header=header,
        rows=table_rows,
        out_path=FIG / "metrics_table.png",
    )
    render_confusion_matrix(cm_json, FIG / "valence_3class_confusion_matrix.png")
    print("Saved:", FIG / "metrics_table.png")
    print("Saved:", FIG / "valence_3class_confusion_matrix.png")


if __name__ == "__main__":
    main()

